-- This file and its contents are licensed under the Apache License 2.0.
-- Please see the included NOTICE for copyright information and
-- LICENSE-APACHE for a copy of the license.

DROP FUNCTION wait_worker_counts(integer, integer, integer, integer);
DROP VIEW worker_counts;
DROP FUNCTION wait_for_bgw_scheduler(name,int,int);


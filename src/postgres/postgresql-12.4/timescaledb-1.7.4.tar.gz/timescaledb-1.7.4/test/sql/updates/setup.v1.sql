-- This file and its contents are licensed under the Apache License 2.0.
-- Please see the included NOTICE for copyright information and
-- LICENSE-APACHE for a copy of the license.

\ir setup.bigint.sql
\ir setup.insert_bigint.v1.sql
\ir setup.timestamp.sql
\ir setup.insert_timestamp.sql

DROP FUNCTION IF EXISTS _timescaledb_internal.timescale_trigger_names();
DROP FUNCTION IF EXISTS _timescaledb_internal.main_table_insert_trigger() CASCADE;
DROP FUNCTION IF EXISTS _timescaledb_internal.main_table_after_insert_trigger() CASCADE;

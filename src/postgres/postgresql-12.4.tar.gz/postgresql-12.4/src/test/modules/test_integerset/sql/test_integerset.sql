CREATE EXTENSION test_integerset;

--
-- All the logic is in the test_integerset() function. It will throw
-- an error if something fails.
--
SELECT test_integerset();
